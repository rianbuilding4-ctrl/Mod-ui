# PurpleVision HUD RPG (development source)

Target: Minecraft Java 1.21.11, Fabric Loader >= 0.19.5, Java 21, Fabric API 0.141.6+1.21.11.

## Features in this source
- Client HUD: FPS, biome, game version, world day, real-world clock, WASD key states.
- `P`: profile screen.
- `O`: settings screen.
- Settings: six accent themes, panel opacity, HUD scale.
- Client-only; no server installation required.

## Build
Use JDK 21 and Gradle 8.14+ (or the version required by Fabric Loom 1.14.10), then run:

`gradle build`

The distributable remapped JAR should appear in `build/libs/`.

## Important validation note
This is a development source project, not a tested release JAR. It has not been compiled or launched in ZalithLauncher in this environment. Check compilation against the exact Yarn/Fabric API versions before installing. The profile panel currently displays the player name; drawing the live skin-face texture is a follow-up implementation task.
