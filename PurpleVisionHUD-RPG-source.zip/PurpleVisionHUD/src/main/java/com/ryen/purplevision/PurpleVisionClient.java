package com.ryen.purplevision;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.hud.HudElementRegistry;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

public class PurpleVisionClient implements ClientModInitializer {
    private static KeyBinding profileKey, settingsKey;
    private static int theme = 0;
    private static int opacity = 190;
    private static float scale = 1.0f;
    private static final int[] ACCENTS = {0xFFB45CFF, 0xFFFF5555, 0xFF55AAFF, 0xFF55DD88, 0xFFFFC34D, 0xFFFF75C8};
    private static final String[] THEMES = {"Purple", "Red", "Blue", "Green", "Gold", "Pink"};
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    @Override public void onInitializeClient() {
        profileKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.purplevision.profile", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, "category.purplevision"));
        settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding("key.purplevision.settings", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_O, "category.purplevision"));
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (profileKey.wasPressed()) client.setScreen(new ProfileScreen());
            while (settingsKey.wasPressed()) client.setScreen(new SettingsScreen());
        });
        HudElementRegistry.addLast(Identifier.of("purplevisionhud", "overlay"), (draw, tickCounter) -> renderHud(draw));
    }

    private static int accent() { return ACCENTS[Math.floorMod(theme, ACCENTS.length)]; }
    private static int panel() { return (Math.max(0, Math.min(255, opacity)) << 24) | 0x00100918; }

    private static void renderHud(DrawContext d) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null || mc.world == null || mc.options.hudHidden) return;
        int a = accent(), p = panel();
        int sw = mc.getWindow().getScaledWidth(), sh = mc.getWindow().getScaledHeight();
        int x = 7, y = 7, w = Math.round(164 * scale), h = Math.round(77 * scale);
        d.fill(x, y, x+w, y+h, p); d.fill(x, y, x+2, y+h, a);
        int line = Math.max(9, Math.round(12 * scale));
        d.drawTextWithShadow(mc.textRenderer, "FPS  " + mc.getCurrentFps(), x+8, y+6, 0xFFFFFFFF);
        String biome = mc.world.getBiome(mc.player.getBlockPos()).getKey().map(k -> k.getValue().getPath()).orElse("unknown");
        d.drawTextWithShadow(mc.textRenderer, "BIOME  " + biome, x+8, y+6+line, 0xFFE8DDF5);
        d.drawTextWithShadow(mc.textRenderer, "MC  " + mc.getGameVersion(), x+8, y+6+line*2, 0xFFE8DDF5);
        long day = mc.world.getTimeOfDay() / 24000L + 1;
        d.drawTextWithShadow(mc.textRenderer, "DAY  " + day, x+8, y+6+line*3, 0xFFE8DDF5);

        int rx = sw - 94;
        d.fill(rx, 7, rx+87, 31, p); d.fill(rx, 7, rx+2, 31, a);
        d.drawTextWithShadow(mc.textRenderer, LocalTime.now().format(CLOCK), rx+9, 15, 0xFFFFFFFF);
        d.fill(7, sh-48, 76, sh-7, p);
        key(d, "W", 31, sh-45, mc.options.forwardKey.isPressed(), a, p);
        key(d, "A", 14, sh-27, mc.options.leftKey.isPressed(), a, p);
        key(d, "S", 31, sh-27, mc.options.backKey.isPressed(), a, p);
        key(d, "D", 48, sh-27, mc.options.rightKey.isPressed(), a, p);
        d.drawTextWithShadow(mc.textRenderer, "P PROFILE  |  O UI", 84, sh-25, a);
    }

    private static void key(DrawContext d, String s, int x, int y, boolean down, int accent, int panel) {
        d.fill(x, y, x+15, y+15, down ? accent : panel); d.drawBorder(x, y, 15, 15, accent);
        d.drawCenteredTextWithShadow(MinecraftClient.getInstance().textRenderer, s, x+7, y+3, 0xFFFFFFFF);
    }

    private static class ProfileScreen extends Screen {
        ProfileScreen() { super(Text.literal("PurpleVision Profile")); }
        @Override protected void init() { addDrawableChild(ButtonWidget.builder(Text.literal("UI Settings"), b -> client.setScreen(new SettingsScreen())).dimensions(width/2-70, height/2+42, 140, 20).build()); }
        @Override public void render(DrawContext d, int mx, int my, float delta) {
            renderBackground(d, mx, my, delta); int cx=width/2, cy=height/2, a=accent();
            d.fill(cx-112,cy-62,cx+112,cy+70,panel()); d.fill(cx-112,cy-62,cx+112,cy-60,a);
            d.drawCenteredTextWithShadow(textRenderer,"PLAYER PROFILE",cx,cy-48,a);
            String name=client.player==null?"Unknown":client.player.getGameProfile().getName();
            d.drawCenteredTextWithShadow(textRenderer,"PLAYER  "+name,cx,cy-22,0xFFFFFFFF);
            d.drawCenteredTextWithShadow(textRenderer,"FPS  "+client.getCurrentFps(),cx,cy-5,0xFFE8DDF5);
            d.drawCenteredTextWithShadow(textRenderer,"BIOME  "+(client.world==null?"-":client.world.getBiome(client.player.getBlockPos()).getKey().map(k->k.getValue().getPath()).orElse("unknown")),cx,cy+11,0xFFE8DDF5);
            super.render(d,mx,my,delta);
        }
        @Override public boolean shouldPause(){return false;}
    }

    private static class SettingsScreen extends Screen {
        SettingsScreen(){ super(Text.literal("PurpleVision Settings")); }
        @Override protected void init(){
            int cx=width/2, y=height/2-48;
            addDrawableChild(ButtonWidget.builder(Text.literal("Theme: "+THEMES[theme]), b->{theme=(theme+1)%THEMES.length; b.setMessage(Text.literal("Theme: "+THEMES[theme]));}).dimensions(cx-90,y,180,20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Panel opacity: "+opacity), b->{opacity+=25;if(opacity>240)opacity=70;b.setMessage(Text.literal("Panel opacity: "+opacity));}).dimensions(cx-90,y+26,180,20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("HUD size: "+Math.round(scale*100)+"%"), b->{scale+=0.1f;if(scale>1.4f)scale=0.8f;b.setMessage(Text.literal("HUD size: "+Math.round(scale*100)+"%"));}).dimensions(cx-90,y+52,180,20).build());
            addDrawableChild(ButtonWidget.builder(Text.literal("Done"), b->close()).dimensions(cx-90,y+82,180,20).build());
        }
        @Override public void render(DrawContext d,int mx,int my,float delta){renderBackground(d,mx,my,delta);d.drawCenteredTextWithShadow(textRenderer,"PURPLEVISION RPG UI",width/2,height/2-72,accent());super.render(d,mx,my,delta);}
        @Override public boolean shouldPause(){return false;}
    }
}
